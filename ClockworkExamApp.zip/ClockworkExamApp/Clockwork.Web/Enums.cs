﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Clockwork.Web
{
    public enum ResultType
    {
        SUCCESS = 0,
        FAIL
    }

    public enum HttpType
    {
        POST = 0,
        GET
    }
}